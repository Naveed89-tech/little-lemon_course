import "./Testimonial.css";
// import { ReactComponent as Logo } from "./images/Logo.svg";

import testimonialOne from "./images/1.jpg";
import testimonialTwo from "./images/2.jpg";
import testimonialThree from "./images/3.jpg";
import testimonialFour from "./images/4.jpg";
import riders from "./images/riders.svg";

function Testimonial() {
  return (
    <section className="testimonial" id="testmonial">
      <div className="container">
        <div className="testimonial-heading">
          <span className="heading-tertiary ">Testimonials</span>
          <h2 className="heading-secondary">Once You Try,You Can'nt Go Back</h2>
        </div>

        <div className="testimonials">
          {/* first testimonial  */}
          <div className="testimonial-box">
            <figure className="testimonial-image">
              <img
                src={testimonialOne}
                alt="our happy customer "
                className="meal-image"
              />
              <p className="testimonial-name"> -ben spaish</p>
              <blockquote className="testimonial-text">
                If more of us valued food and cheer and song above hoarded gold,
                it would be a merrier world.” – J.R.R. Tolkien s me think, ‘ the
                last cookie with.’” –Cookie Monster
              </blockquote>
              <div className="rating">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>
              </div>
            </figure>
          </div>
          {/* 2nd testimonial  */}
          <div className="testimonial-box">
            <figure className="testimonial-image">
              <img
                src={testimonialTwo}
                alt="our happy customer "
                className="meal-image"
              />
              <p className="testimonial-name"> ‐Lily Mullen-Wood</p>
              <blockquote className="testimonial-text">
                If more of us valued food and cheer and song above hoarded gold,
                it would be a merrier world.” – J.R.R. Tolkien s me think, ‘ the
                last cookie with.’” –Cookie Monster
              </blockquote>
              <div className="rating">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    stroke="#F4CE14"
                  />
                </svg>
              </div>
            </figure>
          </div>
          {/* 3rd testimonial  */}
          <div className="testimonial-box">
            <figure className="testimonial-image">
              <img
                src={testimonialThree}
                alt="our happy customer "
                className="meal-image"
              />
              <p className="testimonial-name"> -Fiona Luca</p>
              <blockquote className="testimonial-text">
                If more of us valued food and cheer and song above hoarded gold,
                it would be a merrier world.” – J.R.R. Tolkien s me think, ‘ the
                last cookie with.’” –Cookie Monster
              </blockquote>
              <div className="rating">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    stroke="#F4CE14"
                  />
                </svg>
              </div>
            </figure>
          </div>
          {/* 4th testimonial  */}
          <div className="testimonial-box">
            <figure className="testimonial-image">
              <img
                src={testimonialFour}
                alt="our happy customer "
                className="meal-image"
              />
              <p className="testimonial-name"> -Ian Barnard</p>
              <blockquote className="testimonial-text">
                If more of us valued food and cheer and song above hoarded gold,
                it would be a merrier world.” – J.R.R. Tolkien s me think, ‘ the
                last cookie with.’” –Cookie Monster
              </blockquote>
              <div className="rating">
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    fill="#F4CE14"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    stroke="#F4CE14"
                  />
                </svg>

                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                    stroke="#F4CE14"
                  />
                </svg>
              </div>
            </figure>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Testimonial;
